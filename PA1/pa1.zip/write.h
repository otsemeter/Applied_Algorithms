#ifndef __WRITE__
#define __WRITE__
#include "tree.h"
void write_pre(FILE * fptr, Tnode * root);
void write_elmore(FILE * fptr, Tnode * root);
#endif